package com.editube.util;

import lombok.Data;

@Data
public class LoginUser {
	private String userId;
}
