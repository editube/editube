package com.editube.dto;

import lombok.Data;

@Data
public class RatingDto {
	private int ra_num;
	private int ra_score;
	private String m_nickname;
	private String ra_content;
	private String ra_nickname;
}
